package *** Votre paquetage ici ***

import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.GestureDetectorCompat
import java.util.Random


class MainActivity : AppCompatActivity(), GestureDetector.OnGestureListener
{
    private lateinit var binding: ActivityMainBinding

    private var views: ArrayList<View> = ArrayList()     // liste de View à gérer
    private var viewSélectionné: View? = null            // indique le view à déplacer par ACTION_MOVE

    private var détecteurGestes: GestureDetectorCompat? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configurer l'activité via liaison de vues
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ajouter les deux View du layout aux View à gérer
        views.add(binding.viewRouge)
        views.add(binding.viewBleu)

        // Installer un gestionnaire onTouch sur l'arrière-plan de l'activité
        binding.mainLayout.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View, ev: MotionEvent): Boolean {
                gérerOnTouchSurLayout(ev)
                return true
            }
        })

        // Installer un gestionnaire OnDoubleTap sur l'activité
        this.détecteurGestes = GestureDetectorCompat(this, this)
    }

    // Fonction gérant les touchers du layout
    private fun gérerOnTouchSurLayout(geste: MotionEvent) {
        val x = geste.x
        val y = geste.y
        val action = geste.actionMasked
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                // Déterminer si un View a été sélectionné
                viewSélectionné = null
                for (view in views) {
                    if (positionSurView(view, x, y)) {
                        viewSélectionné = view
                        break
                    }
                }

                // Amener le View sélectionné (s'il y en a un) à l'avant
                viewSélectionné?.bringToFront()
            }

            MotionEvent.ACTION_UP -> {
                // On relâche le view sélectionné (s'il y en avait un)
                viewSélectionné = null
            }

            MotionEvent.ACTION_MOVE -> {
                // On doit travailler avec une variable locale car le viewélectionné
                // peut être sujet à un conflit d'accès dû au multitâche
                val sélection = viewSélectionné
                if (sélection != null) {
                    // Si le view fut sélectionnée dans ACTION_DOWN, on le repositionne
                    // à la position actuelle du toucher
                    centrerViewSurPosition(sélection, x, y)
                }
            }

            else -> {}
        }

        // Passer l'évènement au gestionnaire de gestes
        this.détecteurGestes?.onTouchEvent(geste);
    }

    // Fonction indiquant si la position donnée est sur le view donné
    private fun positionSurView(v: View, x: Float, y: Float): Boolean {
        if (v == null)
            return false;

        val origineX: Float = v.x
        val origineY: Float = v.y
        val opposéX: Float = origineX + v.width
        val opposéY: Float = origineY + v.height
        return x >= origineX && x <= opposéX && y >= origineY && y <= opposéY
    }

    // Repositionne le view donné afin qu'il soit centré sur la position donnée
    private fun centrerViewSurPosition(v: View, x: Float, y: Float) {
        if (v != null) {
            v.x = x - v.width / 2
            v.y = y - v.height / 2
        }
    }

    // Retourne une couleur sélectionnée au hasard
    private fun getCouleurAléatoire(): Int {
        val random = Random()
        return Color.argb(255, random.nextInt(256), random.nextInt(256), random.nextInt(256))
    }

    // Ajoute un View à la position donnée ainsi qu'aux View à gérer
    private fun ajouterView(x: Float, y: Float) {
        val view = View(this)
        binding.mainLayout.addView(view)
        val dps = 40f
        val scale = resources.displayMetrics.density
        val pixels = (dps * scale).toInt()
        view.layoutParams = ConstraintLayout.LayoutParams(pixels, pixels)
        view.x = x - pixels / 2
        view.y = y - pixels / 2
        view.setBackgroundColor(getCouleurAléatoire())

        views.add(view)
    }

    // Gestionnaire déclenché lors d'un déposer du doigt
    override fun onDown(event: MotionEvent): Boolean {
        return true
    }

    // Gestionnaire déclenché lors d'un swap avec les doigts
    override fun onFling(event1: MotionEvent, event2: MotionEvent,
                         velocityX: Float, velocityY: Float): Boolean {
        return true
    }

    // Gestionnaire déclenché lors d'un toucher prolongé
    override fun onLongPress(event: MotionEvent) {
    }

    // Gestionnaire déclenché lors d'un balayage en bordure d'activité
    override fun onScroll(e1: MotionEvent, e2: MotionEvent,
                          distanceX: Float, distanceY: Float): Boolean {
        return true
    }

    // Gestionnaire déclenché lorsque le doigt est déposé sur une position
    // pouvant être confondue avec un début de balayage, mais pas encore déplacé
    override fun onShowPress(event: MotionEvent) {
    }

    // Gestionnaire détaillé du toucher simple (déclenché lorsque le doigt est
    // levé).
    override fun onSingleTapUp(event: MotionEvent): Boolean {
        return true
    }
}
