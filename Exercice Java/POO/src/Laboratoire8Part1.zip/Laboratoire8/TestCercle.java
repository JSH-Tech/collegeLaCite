package Laboratoire8;

public class TestCercle {
    public static void main(String[] args) {
        Cercle cercle=new Cercle();

        cercle.setRayon(8);
        cercle.surface();
        cercle.perimetre();
        cercle.afficher();
    }
}
