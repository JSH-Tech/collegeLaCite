﻿// See https://aka.ms/new-console-template for more information
const int nbMystere = 7;
const int nbMin = 1;
const int nbMax = 10;

Console.WriteLine("Bienvenue dans la jeu \"Nombre mystère\"");

bool gagne = false;
List<int> nombresJoues = new List<int>();
string indication = "";

while (!gagne)
{
    Console.Clear();
    Console.WriteLine(indication);
    
    if (nombresJoues.Count > 0)
    {
        Console.Write("Nombres déjà joués : ");
        foreach (int nb in nombresJoues)
        {
            Console.Write($" {nb} ");
        }
        Console.WriteLine();
    }

    int nbSaisi = 0;
    while(nbSaisi < nbMin || nbSaisi > nbMax)
    {
        Console.WriteLine($"Veuillez entrer un nombre entre {nbMin} et {nbMax}");
        try
        {
            nbSaisi = int.Parse(Console.ReadLine());
        }
        catch
        {
            nbSaisi = 0;
        }
    }
    nombresJoues.Add(nbSaisi);

    if (nbSaisi == nbMystere)
    {
        Console.WriteLine("Vous avez gagné !");
        gagne = true;
    }
    else
    {
        if (nbSaisi > nbMystere)
        {
            indication = "Le nombre mystère est plus petit";
        }
        else
        {
            indication = "Le nombre mystère est plus grand";
        }
    }
}