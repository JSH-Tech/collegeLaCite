﻿// See https://aka.ms/new-console-template for more information
const int nbMystere = 7;

Console.WriteLine("Bienvenue dans la jeu \"Nombre mystère\"");

bool gagne = false;

while (!gagne)
{
    Console.WriteLine("Veuillez entrer un nombre entre 1 et 10");
    int nbSaisi = int.Parse(Console.ReadLine());

    if (nbSaisi == nbMystere)
    {
        Console.WriteLine("Vous avez gagné !");
        gagne = true;
    }
    else
    {
        if (nbSaisi > nbMystere)
        {
            Console.WriteLine("Le nombre mystère est plus petit");
        }
        else
        {
            Console.WriteLine("Le nombre mystère est plus grand");
        }
    }
}