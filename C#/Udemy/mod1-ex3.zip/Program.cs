﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Veuillez saisir votre prénom");
string prenom = Console.ReadLine();

Console.WriteLine("Veuillez saisir votre âge");
string age = Console.ReadLine();

Console.WriteLine($"Bonjour {prenom}, vous avez {age} ans");