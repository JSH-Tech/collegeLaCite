﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Veuillez saisir votre prénom");
string saisie = Console.ReadLine();
Console.WriteLine("Bonjour");
Console.WriteLine(saisie);