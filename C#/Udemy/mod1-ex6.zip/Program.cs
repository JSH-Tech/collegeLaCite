﻿// See https://aka.ms/new-console-template for more information
const int majorite = 18;
Console.WriteLine("Veuillez saisir votre prénom");
string prenom = Console.ReadLine();

Console.WriteLine("Veuillez saisir votre âge");
int age = int.Parse(Console.ReadLine());

Console.WriteLine($"Bonjour {prenom}, vous avez {age} ans");
//Console.WriteLine("Bonjour " + prenom + ", vous avez " + age + " ans");
if(age >= majorite) 
{
    Console.WriteLine("Vous êtes majeur");
}
else
{
    Console.WriteLine("Vous êtes mineur");
}